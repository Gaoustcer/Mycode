#include <iostream>
#include <string>
#include "antlr4-runtime.h"
#include "relop.h"
#define MAX 1000

using namespace antlr4;

int main(int argc, const char* argv[])
{
    char Input[MAX_LENGTH];
    fgets(Input, MAX, stdin);
    ANTLRInputStream input(Input);
    relop lexer(&input);
    CommonTokenStream tokens(&lexer);
    tokens.fill();


    return 0;
}
