// expr lexer
#include <stdlib.h>
#include <string.h>
#include "pl0.h"
#define MAX 1000
#define OTHER 1024
//#define COMPARE 2048
int findchar(char c){
    return (c=='=')?1:((c=='>')?2:((c=='<')?3:0));
}//1 means =,2 means >,3 means <
#ifndef LEXERGEN
void analyze(char *str){
    int state=0;
    int i;
    int j=0;
    for(i=0;i<strlen(str);i++){
        switch (state)
        {
        case 2:
            printf("(relop,<=)");
            state=0;
            break;
        case 3:
            printf("(relop,<>)");
            state=0;
            break;
        case 4:
            printf("(relop,<)");
            state=0;
            break;
        case 5:
            printf("(relop,=)");
            state=0;
            break;
        case 7:
            printf("(relop,>=)");
            state=0;
            break;
        case 8:
            printf("(relop,>)");
            state=0;
            break;
        case 9:
            if(findchar(str[i])!=0)
                printf("(other,%d)",j);
                state=0;
            break;
        default:
            break;
        }
        if(state==0){
            switch (findchar(str[i]))
            {
            case 1:
                state=5;
                j=0;
                break;
            case 2:
                state=6;
                j=0;
                break;
            case 3:
                state=1;
                j=0;
                break;
            default:
                state=9;
                j++;
                break;
            }
        }
        else if(state==1){
            switch (findchar(str[i]))
            {
            case 1:
                state=2;
                j=0;
                break;
            case 2:
                state=3;
                j=0;
                break;
            case 3:
                state=4;
                if(i!=0){
                    i--;
                }
                j=0;
                break;
            default:
                printf("(relop,<)");
                state=9;
                j++;
                break;
            }
        }
        else if(state==6){
            switch (findchar(str[i]))
            {
            case 1:
                state=7;
                j=0;
                break;
            case 2:
                state=8;
                if(i!=0){
                    i--;
                }
                j=0;
                break;
            case 3:
                state=8;
                if(i!=0){
                    i--;
                }
                j=0;
                break;
            default:
                printf("(relop,>)");
                state=9;
                j++;
                break;
            }
        }
        else if(state==9){
            switch (findchar(str[i]))
            {
            case 0:
                state==9;
                j++;
                break;
            case 1:
                printf("(other,%d)",j);
                state=5;
                j=0;
                break;
            case 2:
                printf("(other,%d)",j);
                state=6;
                j=0;
                break;
            case 3:
                printf("(other,%d)",j);
                state=1;
                j=0;
                break;
            default:
                break;
            }
        }
        }
        switch (state)
        {
        case 1:
            printf("(relop,<)");
            break;
        case 6:
            printf("(relop,>)");
            break;
        case 2:
            printf("(relop,<=)");
            break;
        case 3:
            printf("(relop,<>)");
            break;
        case 4:
            printf("(relop,<)");
            printf("(other,%d)",j);
            break;
        case 5:
            printf("(relop,=)");
            break;
        case 7:
            printf("(relop,>=)");
            break;
        case 8:
            printf("(relop,>)");
            printf("(other,%d)",j);
            break;
        case 9:            
            printf("(other,%d)",j);
            break;
        default:
            break;
        }
}
/*void getch() {
    int length
    if(cc==ll){
	if(feof(infile)){
	    exit(1);
	}
	ll=0; cc=0;
	while((!feof(infile))&&((ch=getc(infile))!='\n')){
	    ll=ll+1; line[ll]=ch;
	}
	printf("\n");
	ll=ll+1; line[ll]=' ';
    }
    cc=cc+1; ch=line[cc];
}

void getsym(){
    long i,j,k;

    while(ch==' '||ch=='\t'){
	getch();
    }
    if(isdigit(ch)){ // number
	k=0; num=0; sym=number;
	do{
	    num=num*10+(ch-'0');
	    k=k+1; getch();
	}while(isdigit(ch));
	if(k>nmax){
	    error(31);
	}
    } else if (ch=='+') {
	sym=plus;
	getch();
    } else {
	sym=nul;
	getch();
    }
}
*/
#endif

int main(int argc, char *argv[])
{
	char Strline[MAX];
	printf("please input source program file name: ");
	scanf("%s", infilename);
	if ( (infile=fopen(infilename, "r"))==NULL ) {
		printf("File %s can't be opened.\n", infilename);
		exit(1);
	}
#ifdef LEXERGEN
	extern FILE * yyin;
	yyin=infile;
#endif
	while (!feof(infile)) 
    { 
        fgets(Strline,1024,infile);  //读取一行
    	//printf("%s\n", StrLine); //输出
		analyze(Strline);
    } 
	/*getsym();	
	while (sym) {
		switch(sym) {
		case number:
			printf("%ld", num);
			break;
		case plus:
			printf("+"); break;
		}
		getsym();
	}*/
	printf("File %s has already been scanned.\n", infilename);
	fclose(infile);
}