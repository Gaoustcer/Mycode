#include<iostream>
#include<stdio.h>
#include "antlr4-runtime.h"
#include "labLexer.h"
using namespace antlr4;
int main(){
    char *str[100];
    gets(str);
    ANTLRInputStream input(str);
    relop tokens(&input);
    tokens.fill();
    for (auto token : tokens.getTokens()) {
        std::cout << token->toString() << std::endl;
    }

    return 0;
}