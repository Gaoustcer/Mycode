#include <iostream>
#include<stdio.h>
#include "antlr4-runtime.h"
#include "labLexer.h"

using namespace antlr4;

int main(int argc, const char* argv[]) {
    char str[100];
    gets(str);
    ANTLRInputStream input(str);
    relop lexer(&input);
    CommonTokenStream tokens(&lexer);
    
    tokens.fill();

    return 0;
}